JHN WEAR V6

WHAT'S NEW
- Real backend API for products, orders and store settings
- Orders are stored server-side in data/db.json
- Secure admin password via ADMIN_PASSWORD environment variable
- Admin dashboard at /admin.html
- Product add/edit/delete
- Order status updates
- Store settings update
- Customer orders no longer depend on the customer's localStorage for saving the order

LOCAL RUN
1. Install Node.js 18+
2. Open this folder in Terminal
3. Run: npm install
4. Set ADMIN_PASSWORD (optional; default is 1234 for demo)
5. Run: npm start
6. Open http://localhost:3000
7. Admin: http://localhost:3000/admin.html

IMPORTANT
This V6 is deployment-ready but is not hosted online by this ZIP. To make it a public store, deploy the folder to a Node.js host (Render/Railway/VPS/etc.) and set ADMIN_PASSWORD to a strong password. For a serious production store, move the JSON database to PostgreSQL/Supabase and add HTTPS, rate limiting, backups and proper role-based authentication.
