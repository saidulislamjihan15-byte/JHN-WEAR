JHN WEAR V7
V7 upgrades the V6 storefront with:
- Product search and category filters
- Size and color selection
- Wishlist
- Stock / out-of-stock display
- Sale price support
- Improved product modal
- Cart quantity controls
- Existing V6 admin/order flow remains the base

IMPORTANT:
This is still a front-end/local-storage stage unless the V6 backend is running and the frontend API is wired to it. Do not treat localStorage admin/PIN as secure production authentication.
